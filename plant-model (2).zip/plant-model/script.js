let model;

async function init() {
  const URL = "https://teachablemachine.withgoogle.com/models/dVlE5j6ue/";
  const modelURL = URL + "model.json";
  const metadataURL = URL + "metadata.json";

  model = await tmImage.load(modelURL, metadataURL);
  console.log("Model loaded.");
}

init();

document.getElementById("upload").addEventListener("change", async function (event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async function () {
    const img = document.createElement("img");
    img.src = reader.result;
    img.onload = async () => {
      document.body.appendChild(img);
      const prediction = await model.predict(img);
      const result = prediction
        .map(p => `${p.className}: ${(p.probability * 100).toFixed(2)}%`)
        .join("\n");

      document.getElementById("prediction").innerText = result;
    };
  };
  reader.readAsDataURL(file);
});
